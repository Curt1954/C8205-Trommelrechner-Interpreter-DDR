; 0020_umspeichern.asm  -  symbolisches Assemblerprogramm zu Testdatei 0020_umspeichern.txt
; #DOK-0020 Test Umspeichern
; #SPEI-0020 4000-4020
; #SPEI-0020 6000-6020
; #SPEI-1020 3711-3730
; #PROT STUFE=2
; #TROMMEL=KEEP                # Trommel unveraendert (Stand des vorigen Laufs), ausdruecklich
; Automatisch vergebene Symbole (Zahl = Adresse im Original): m = Befehlszelle/Sprungziel, d = Daten-/Arbeitszelle, t = Textzelle; Symbole
;   ohne Zelle im Programm sind am Ende per abs definiert.

                start
m0000:          000     m3700
                equ     03700
m3700:          241     d3730
m3701:          210     d3723
                210     d3726
                240     m3711
                210     d3725
                240     m3713
                210     d3724
                240     m3712
                164     01020
m3711:          000     m0000
m3712:          000     m0000
m3713:          000     m0000
                211     d3730
                210     d3727
                240     d3730
                330     d6000
                140     m3701
                164     00020
                020     0
; Beginn Datenbereich
d3723:          dw      04000000
d3724:          dw      01777777
d3725:          dw      030
d3726:          dw      0211
d3727:          dw      01000
d3730:          dw      020
                equ     04000
                dw      017000
                dw      01
                dw      02
                dw      04
                dw      010
                dw      011
                dw      012
                dw      014
                dw      020
                dw      021
                dw      022
                dw      024
                dw      030
                dw      031
                dw      032
                dw      034
                dw      040
                equ     06000
d6000:          dw      020

                end

; Tastenfolge:
; H G R
;
; Prüfungen:
;#PRUEFE-START
; BZ=3723 AC=00000020000 AR=0000 FE=0 FUE=0 BS=0 US=1 E=0 A=0 V1=0 V2=1
;
; 4000: 00000000000
; 4001: 00000000000
; 4002: 00000000000
; 4003: 00000000000
; 4004: 00000000000
; 4005: 00000000000
; 4006: 00000000000
; 4007: 00000000000
; 4010: 00000000000
; 4011: 00000000000
; 4012: 00000000000
; 4013: 00000000000
; 4014: 00000000000
; 4015: 00000000000
; 4016: 00000000000
; 4017: 00000000000
; 4020: 00000000040
; 6000: 00000017000
; 6001: 00000000001
; 6002: 00000000002
; 6003: 00000000004
; 6004: 00000000010
; 6005: 00000000011
; 6006: 00000000012
; 6007: 00000000014
; 6010: 00000000020
; 6011: 00000000021
; 6012: 00000000022
; 6013: 00000000024
; 6014: 00000000030
; 6015: 00000000031
; 6016: 00000000032
; 6017: 00000000034
; 6020: 00000000000
;#PRUEFE-ENDE
;
;
