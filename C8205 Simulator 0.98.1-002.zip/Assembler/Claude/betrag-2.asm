; z = -|a+b| + |-b+c| + |-c+d|   mit Unterprogramm BETRAG: res := |px + py|
; #DOK-0001 Test betrag: z = -|a+b| + |-b+c| + |-c+d| mit a=5 b=3 c=7 d=2, erwartet z=1
; #PROT STUFE=2
; #TROMMEL=KEEP                # Trommel unveraendert (Stand des vorigen Laufs), ausdruecklich
                start
                000     haupt
a:              dw      5            ; Testwerte, bitte anpassen
b:              dw      3
c:              dw      7
d:              dw      2
z:              db      1            ; Ergebnis
px:             db      1            ; Parameter x
py:             db      1            ; Parameter y
res:            db      1            ; Ergebnis des Unterprogramms
rueck:          db      1            ; hier steht zur Laufzeit der Rücksprung

; ---- Hauptprogramm ----
haupt:          211     a            ; |a+b|
                240     px
                211     b
                240     py
                025     betrag       ; Sprung mit Rückkehrabsicht
                221     res          ; ac := -|a+b|
                240     z

                221     b            ; |-b+c|: x = c, y = -b
                240     py
                211     c
                240     px
                025     betrag
                211     z
                210     res          ; z := z + |-b+c|
                240     z

                221     c            ; |-c+d|: x = d, y = -c
                240     py
                211     d
                240     px
                025     betrag
                211     z
                210     res          ; z := z + |-c+d|
                240     z
                020     0            ; Halt, Ergebnis in z

; ---- Unterprogramm BETRAG: res := |px + py| ----
betrag:         240     rueck        ; Rücksprungwort aus AC sichern
                211     px
                210     py           ; ac := x+y
                240     res
                050     rueck        ; Positivsprung: x+y >= 0, also fertig
                221     res          ; sonst ac := 0 - res
                240     res
                000     rueck
ende:           end

; Sollwerte von Hand hergeleitet. z = -|5+3| + |-3+7| + |-7+2| = -8 + 4 + 5 = 1; res zuletzt |2-7| = 5; Halt auf 0041.
;#PRUEFE-START
; BZ=0042 AC=00000000001 US=1
; 0005: 00000000001   # z
; 0010: 00000000005   # res (letzter Aufruf)
;#PRUEFE-ENDE
